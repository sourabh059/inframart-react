

export function DeleteCategory(id){


console.log("inside delete category");
console.log(id)

    return(
        <>
        </>
    )
}