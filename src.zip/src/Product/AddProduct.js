import { useState, useEffect } from "react";
import '../Product/Product.css'
import axios from "axios";
import { useParams } from "react-router-dom";
export function AddProduct() {

    const [category, setCategory] = useState([]);

    useEffect(() => {
        const getCategory = async () => {
            const res = await axios('http://localhost:8081/getcategories');
            setCategory(res.data);
        };

        getCategory();
    }, []);

    const [addproduct, setAddproduct] = useState({
        productName: "",
        productDescription: "",
        productPrice: "",
        productUnit: "",
        productCategory: "",
    })


    function handler(e) {
        const { name, value } = e.target
        setAddproduct({

            ...addproduct, [name]: value
        })
        console.log("addproduct",addproduct)
    }

    const file = addproduct.file;
    const [prodimage, setProductimage] = useState({
        file: ""
    })



    function handler1(e) {
        const { name, value } = e.target
        setProductimage({ ...prodimage, [name]: value })
        console.log("inimage handler", prodimage)
    }

    // const{prodimage}=useParams()
    console.log(prodimage);
    function handler2(event) {
        event.preventDefault();

        console.log(addproduct)
        console.log("sendhandlerfilepatl", prodimage)

        let promise1 = axios.post("http://localhost:8081/addproduct", addproduct,
        
            {params: { image: prodimage }}, //Add userID as a param 
            { headers: { "Content-Type": "multipart/form-data" },
            });
            promise1.then(response => {
                console.log(response.data)
            })
        promise1.catch(error => {
            console.log("not send")
        })
    }





    return (
        <>
            <center className="addproduct">
                <form class="form-horizontal">
                    <fieldset>
                        <legend>ADD-PRODUCT</legend>
                        <div class="form-group">
                            <label class="" for="product_name">PRODUCT NAME</label>
                            <div class="col-md-4">
                                <input type="text" id="productName" name="productName" autoFocus="on" required
                                    value={addproduct.productName}
                                    onChange={handler}
                                />

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="product_name_fr">PRODUCT DESCRIPTION</label>
                            <div class="col-md-4">
                                <input type="text" id="productDescription" name="productDescription"
                                    value={addproduct.productDescription}
                                    onChange={handler} />

                            </div>
                        </div>

                        {/* <!-- Select Basic --> */}
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="product_categorie">PRODUCT PRICE</label>
                            <div class="col-md-4">
                                <input type="text" id="productPrice" name="productPrice"
                                    value={addproduct.productPrice}
                                    onChange={handler}
                                />
                            </div>
                        </div>
                        {/* <!-- Text input--> */}
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="available_quantity">PRODUCT QUANTITY</label>
                            <div class="col-md-4">
                                <input type="text" id="productUnit" name="productUnit"
                                    value={addproduct.productUnit}
                                    onChange={handler}
                                />

                            </div>
                        </div>



                        {/* <!-- Textarea --> */}
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="product_description">PRODUCT CATEGORY</label>
                            <div class="col-md-4">
                                <select id="productCategory" name="productCategory"
                                    value={addproduct.productCategory}
                                    onChange={handler}
                                >
                                    {category.map(cat => {
                                        return (
                                            <option>{cat.categoryName}</option>
                                        )

                                    })}
                                </select>
                            </div>
                        </div>


                        <div class="form-group">
                            <label class="col-md-4 control-label" for="product_name_fr">PRODUCT IMAGE</label>
                            <div class="col-md-4">
                                <input type="file" id="file" name="file"
                                    value={prodimage.file}
                                   onChange={handler1}
                                />
                            </div>
                        </div>

                        {/* <!-- Button --> */}
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="singlebutton"></label>
                            <div class="col-md-4">
                                <button  id="addproductbtn" onClick={handler2}>Add</button>
                            </div>
                        </div>

                    </fieldset>
                </form>
            </center>
        </>
    )
}