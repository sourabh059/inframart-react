import { useState,useEffect} from "react";
import axios from "axios";

export function UploadImage() {

    const [category, setCategory] = useState([]);

    useEffect(() => {
        const getCategory = async () => {
            const res = await axios('http://localhost:8081/getcategories');
            setCategory(res.data);
        };

        getCategory();
    }, []);

    const [addproduct, setAddproduct] = useState({
        productName: "",
        productDescription: "",
        productPrice: "",
        productUnit: "",
        productCategory: "",
    })

    function handler(e) {
        const { name, value } = e.target
        setAddproduct({

            ...addproduct, [name]: value
        })
        console.log("addproduct", addproduct)
    }


    // const [imagePreview, setImagePreview] = useState(null);
    // const [imageData, setImageData] = useState(null);
    // const [imageName, setImageName] = useState("");
    // const { image } = useSelector(state => state.upload);

    let imageData;
    const handleUploadClick = event => {
       const file = event.target.files[0];
         imageData = new FormData();
        imageData.append('image', file);
        // imageData.append(' productName', addproduct.productName);
        // imageData.append('productDescription', addproduct.productDescription);
        // imageData.append(' productPrice', addproduct.productPrice);
        // imageData.append('productUnit', addproduct.productUnit);
        // imageData.append('productCategory', addproduct.productCategory);
         imageData.append('product',JSON.stringify(addproduct));
        // setImageData(imageData);
        // setImagePreview(URL.createObjectURL(file));
        // console.log(imageData)
         console.log(file)
         console.log(imageData)
        // console.log(imagePreview)
        // console.log(imageName)
    }

    const uploadImageWithAdditionalData = (e) => {
        e.preventDefault()
        // imageData.append('imageName', imageName);

        let promise1 = axios.post("http://localhost:8081/addproduct",imageData, {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          })
   
        promise1.then(response => {
            console.log(response.data)
        })
        // dispatch(uploadImage(imageData));  addproduct
    };

    return (
        <>
            <center className="addproduct">
                <form class="form-horizontal">
                    <fieldset>
                        <legend>ADD-PRODUCT</legend>
                        <div class="form-group">
                            <label class="" for="product_name">PRODUCT NAME</label>
                            <div class="col-md-4">
                                <input type="text" id="productName" name="productName" autoFocus="on" required
                                    value={addproduct.productName}
                                    onChange={handler}
                                />

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="product_name_fr">PRODUCT DESCRIPTION</label>
                            <div class="col-md-4">
                                <input type="text" id="productDescription" name="productDescription"
                                    value={addproduct.productDescription}
                                    onChange={handler} />

                            </div>
                        </div>

                        {/* <!-- Select Basic --> */}
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="product_categorie">PRODUCT PRICE</label>
                            <div class="col-md-4">
                                <input type="text" id="productPrice" name="productPrice"
                                    value={addproduct.productPrice}
                                    onChange={handler}
                                />
                            </div>
                        </div>
                        {/* <!-- Text input--> */}
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="available_quantity">PRODUCT QUANTITY</label>
                            <div class="col-md-4">
                                <input type="text" id="productUnit" name="productUnit"
                                    value={addproduct.productUnit}
                                    onChange={handler}
                                />

                            </div>
                        </div>



                        {/* <!-- Textarea --> */}
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="product_description">PRODUCT CATEGORY</label>
                            <div class="col-md-4">
                                <select id="productCategory" name="productCategory"
                                    value={addproduct.productCategory}
                                    onChange={handler}
                                >
                                    {category.map(cat => {
                                        return (
                                            <option>{cat.categoryName}</option>
                                        )

                                    })}
                                </select>
                            </div>
                        </div>

                        <input
                            accept="image/*"
                            id="upload-profile-image"
                            type="file"
                            onChange={handleUploadClick}
                        />
                        <div class="form-group">
                            <label class="col-md-4 control-label" for="singlebutton"></label>
                            <div class="col-md-4">
                                <button  id="addproductbtn" onClick={uploadImageWithAdditionalData}>Add</button>
                            </div>
                        </div>

                    </fieldset>
                </form>
            </center>
        </>
    )

}