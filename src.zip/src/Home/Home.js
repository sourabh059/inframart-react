import '../Home/Home.css'
export function Home(){
    return (
    <>
        <h1 className="h1"> Welcome to
             Infra-Mart</h1>
    </>


    );
}