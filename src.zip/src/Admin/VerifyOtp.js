
// export function VerifyOtp(){


//     return(
//         <>
//         <input type="text">Verifyotp</input>
//         <button>submit</button>
//         <div dangerouslySetInnerHTML={VerifyOtp()} /> 
//         </>
//     )
// }