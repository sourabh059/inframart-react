import '../Product/Product.css';

import React, { useState, useEffect } from 'react';
import axios from 'axios';

export function Product(){
     
   
    
    const [product, setProduct] = useState([]);
    useEffect(() => {
        const getProducts = async (event) => {
			// event.preventDefault();
            const res = await axios('http://localhost:8081/displayproduct');
            console.log(res.data);
            setProduct(res.data);
        };

        getProducts();
    }, []);



    return(
        <>
        
{/* <ink href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"/>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> */}



<html lang="en">
  <head>
    
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <title>eCommerce Product Detail</title>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet"/>

  </head>

  <body>
	
	
    	
	{product.map(categ => {
            return (
              <>
        
			 <h1> {categ.img.imgid}</h1>
                <div class="container1">
		<div class="card">
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">
						  <div class="tab-pane active" id="pic-1">
						  <img src={"data:"+categ.img.type+";charset=utf-8;base64,"+categ.img.imageData} alt="Description of the image" />
						  {/* <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUiI1UnO78NXI7fYcl9LRaV6KLGfWACqcXrQ&usqp=CAU" /> */}
						  </div>
						  {/* <img src={"data:"+categ.img.type+";base64,"+{...categ.img.imageData} } /> */}
						  {/* <h1>{categ.img.type}{"data:"+categ.img.type+";base64,"+{...categ.img.imageData} }</h1> */}
					
						   {/* <img src={'data:'+{...categ.img.imageData}+';base64,.'+base64_encode({...categ.img.imageData})}></img> */}
						   {/* <img src={"http://img.example.com/test/" + {...categ.img.imageData} +{...categ.img.imageData}}/> */}
						  {/* <img src={URL.createObjectURL(categ.img.imageData)} type={categ.img.type}/> */}
						</div>
					</div>
					<div class="details col-md-6">
						<h3 class="product-title">Bricks</h3>
						<div class="rating">
							<div class="stars">
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<span class="review-no">41 reviews</span>
						</div>
						<p class="product-description">Suspendisse quos? Tempus cras iure temporibus?
                         Eu laudantium cubilia sem sem! Repudiandae et! Massa
                         senectus enim minim sociosqu delectus posuere.</p>
						<h4 class="price">current price: <span>$180</span></h4>
						<p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
						<h5 class="sizes">sizes:
							<span class="size" data-toggle="tooltip" title="small">s</span>
							<span class="size" data-toggle="tooltip" title="medium">m</span>
							<span class="size" data-toggle="tooltip" title="large">l</span>
							<span class="size" data-toggle="tooltip" title="xtra large">xl</span>
						</h5>
						<h5 class="colors">colors:
							<span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
							<span class="color green"></span>
							<span class="color blue"></span>
						</h5>
						<div class="action">
							<button class="add-to-cart btn btn-default" type="button">add to cart</button>
						</div>
					</div>
				</div>  
			</div>    
		</div>
	</div>
              </>
            )

          })}
	<div class="container1">
		<div class="card">
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6">
						
						<div class="preview-pic tab-content">
						  <div class="tab-pane active" id="pic-1"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSk-5Ibt7U9p5yVCZEpKl21R5wJIP09KCq1Hg&usqp=CAU" /></div>
						</div>
					</div>
					<div class="details col-md-6">
						<h3 class="product-title">Steel</h3>
						<div class="rating">
							<div class="stars">
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star checked"></span>
								<span class="fa fa-star"></span>
								<span class="fa fa-star"></span>
							</div>
							<span class="review-no">41 reviews</span>
						</div>
						<p class="product-description"> posuere.</p>
						<h4 class="price">current price: <span>$180</span></h4>
						<p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
						<h5 class="sizes">sizes:
							<span class="size" data-toggle="tooltip" title="small">s</span>
							<span class="size" data-toggle="tooltip" title="medium">m</span>
							<span class="size" data-toggle="tooltip" title="large">l</span>
							<span class="size" data-toggle="tooltip" title="xtra large">xl</span>
						</h5>
						<h5 class="colors">colors:
							<span class="color orange not-available" data-toggle="tooltip" title="Not In store"></span>
							<span class="color green"></span>
							<span class="color blue"></span>
						</h5>
						<div class="action">
							<button class="add-to-cart btn btn-default" type="button">add to cart</button>
						</div>
					</div>
				</div>  
			</div>    
		</div>
	</div>

  </body>
</html>


        </>
    )
}