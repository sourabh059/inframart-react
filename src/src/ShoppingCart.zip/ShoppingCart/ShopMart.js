import Shop from "./Shop";

export function ShopMart()
{
   
  
  return(
    <div>
        <Shop></Shop>
    </div>
  )

}